# dataset.py
import os
from collections import Counter
from typing import List, Tuple
import torch
from torch.utils.data import Dataset
import numpy as np

def read_opcode_file(path: str) -> List[str]:
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        text = f.read().strip()
    # tokens separated by whitespace or newlines
    tokens = text.split()
    return tokens

def build_vocab(data_dir: str, min_freq: int = 1) -> Tuple[dict, dict]:
    """
    Build vocabulary from all opcode files under data_dir.
    Returns (token2idx, idx2token). Index 0 reserved for PAD, 1 for UNK.
    """
    counter = Counter()
    for root, _, files in os.walk(data_dir):
        for fn in files:
            if not fn.endswith('.opcode'):
                continue
            path = os.path.join(root, fn)
            tokens = read_opcode_file(path)
            counter.update(tokens)
    token2idx = {'<PAD>':0, '<UNK>':1}
    idx = 2
    for tok, freq in counter.most_common():
        if freq < min_freq:
            continue
        if tok in token2idx:
            continue
        token2idx[tok] = idx
        idx += 1
    idx2token = {v:k for k,v in token2idx.items()}
    return token2idx, idx2token

class OpcodeDataset(Dataset):
    def __init__(self, data_dir: str, token2idx: dict, seq_len: int = 10000):
        """
        data_dir: root with subfolders for classes (e.g., 'Benign', 'Malware')
        token2idx: mapping token->int
        seq_len: fixed length to pad/truncate sequences
        """
        self.seq_len = seq_len
        self.token2idx = token2idx
        self.samples = []  # list of (path, label)
        # detect classes by subdirectory names
        classes = sorted([d for d in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, d))])
        self.class_to_idx = {c:i for i,c in enumerate(classes)}
        for c in classes:
            folder = os.path.join(data_dir, c)
            for fn in os.listdir(folder):
                if fn.endswith('.opcode'):
                    self.samples.append((os.path.join(folder, fn), self.class_to_idx[c]))
        if len(self.samples) == 0:
            raise ValueError("No .opcode files found under data_dir.")
    def __len__(self):
        return len(self.samples)
    def __getitem__(self, idx):
        path, label = self.samples[idx]
        tokens = read_opcode_file(path)
        seq = [self.token2idx.get(t, self.token2idx['<UNK>']) for t in tokens]
        # pad or truncate
        if len(seq) >= self.seq_len:
            seq = seq[:self.seq_len]
        else:
            seq = seq + [self.token2idx['<PAD>']] * (self.seq_len - len(seq))
        return torch.tensor(seq, dtype=torch.long), torch.tensor(label, dtype=torch.long)