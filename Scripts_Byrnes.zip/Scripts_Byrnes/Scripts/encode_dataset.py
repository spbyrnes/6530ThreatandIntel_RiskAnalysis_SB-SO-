#!/usr/bin/env python3
"""
Encode cleaned .opcode files into integer sequences and save X.pt, y.pt as torch tensors.
Usage:
    python encode_dataset.py --benign cleaned/benign --malware cleaned/malware --seq_len 2000 --outdir encoded
"""
import os, json, argparse
import torch
from glob import glob

def load_vocab(vocab_path="vocab.json"):
    with open(vocab_path,'r') as f:
        return json.load(f)

def encode_file(path, vocab, seq_len):
    toks = []
    with open(path,'r',errors='ignore') as f:
        for line in f:
            tok = line.strip()
            if not tok:
                continue
            toks.append(tok)
    ids = []
    unk = vocab.get("<UNK>")
    for t in toks:
        ids.append(vocab.get(t, unk))
    if len(ids) >= seq_len:
        ids = ids[:seq_len]
    else:
        ids = ids + [0]*(seq_len - len(ids))
    return ids

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--benign", required=True)
    parser.add_argument("--malware", required=True)
    parser.add_argument("--vocab", default="vocab.json")
    parser.add_argument("--seq_len", type=int, default=2000)
    parser.add_argument("--outdir", default="encoded")
    args = parser.parse_args()

    vocab = load_vocab(args.vocab)
    os.makedirs(args.outdir, exist_ok=True)
    X = []
    y = []
    for path in sorted(glob(os.path.join(args.benign, "*.opcode"))):
        X.append(encode_file(path, vocab, args.seq_len))
        y.append(0)
    for path in sorted(glob(os.path.join(args.malware, "*.opcode"))):
        X.append(encode_file(path, vocab, args.seq_len))
        y.append(1)
    X = torch.LongTensor(X)
    y = torch.LongTensor(y)
    torch.save(X, os.path.join(args.outdir, "X.pt"))
    torch.save(y, os.path.join(args.outdir, "y.pt"))
    print("Saved X.pt and y.pt to", args.outdir, "shape:", X.size())

if __name__ == "__main__":
    main()
