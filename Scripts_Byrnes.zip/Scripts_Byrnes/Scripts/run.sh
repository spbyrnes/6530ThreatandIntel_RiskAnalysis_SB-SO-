#!/bin/bash
set -e

# 1. Preprocess benign and malware opcode files
python3 preprocess_opcodes.py data/benign data/benign_clean
python3 preprocess_opcodes.py data/malware data/malware_clean

# 2. Build opcode vocabulary
python3 build_vocab.py data/benign_clean data/malware_clean

# 3. Encode datasets into integer sequences
python3 encode_dataset.py \
  --benign data/benign_clean \
  --malware data/malware_clean \
  --seq_len 2000 \
  --outdir encoded

# 4. Train deep learning model (LSTM classifier)
python3 train.py \
  --encoded encoded \
  --vocab vocab.json \
  --seq_len 2000 \
  --epochs 10

# 5. Evaluate trained model on test set
python3 classificationdl_opcodes.py \
  --encoded encoded \
  --vocab vocab.json \
  --seq_len 2000 \
  --model checkpoints/model.pth
