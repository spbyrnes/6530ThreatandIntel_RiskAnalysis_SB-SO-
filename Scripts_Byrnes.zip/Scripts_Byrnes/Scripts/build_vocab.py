#!/usr/bin/env python3
"""
Build vocab from cleaned .opcode files.
Writes vocab.json (token -> id) and vocab.txt (token<tab>id).
Usage:
    python build_vocab.py cleaned_benign_folder cleaned_malware_folder
"""
import sys, os, json
from collections import OrderedDict

def build(folders):
    seen = {}
    for folder in folders:
        for fname in os.listdir(folder):
            if not fname.endswith(".opcode"):
                continue
            path = os.path.join(folder, fname)
            with open(path, 'r', errors='ignore') as f:
                for line in f:
                    tok = line.strip()
                    if not tok:
                        continue
                    seen.setdefault(tok, 0)
                    seen[tok] += 1
    toks = sorted(seen.keys())
    vocab = OrderedDict()
    idx = 1  # reserve 0 for PAD
    for t in toks:
        vocab[t] = idx
        idx += 1
    # Add UNK as last token
    vocab["<UNK>"] = idx
    return vocab

def main():
    if len(sys.argv) < 3:
        print("Usage: python build_vocab.py cleaned_benign_folder cleaned_malware_folder")
        sys.exit(1)
    folders = sys.argv[1:]
    vocab = build(folders)
    with open("vocab.json","w") as f:
        json.dump(vocab, f, indent=2)
    with open("vocab.txt","w") as f:
        for t,i in vocab.items():
            f.write(f"{t}\t{i}\n")
    print("Wrote vocab.json and vocab.txt. Size:", len(vocab))

if __name__ == "__main__":
    main()
