import torch
from torch.utils.data import DataLoader
from model import OpcodeClassifier, OpcodeDataset  # reuse your model + dataset
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import json

def evaluate(encoded_dir, vocab_file, seq_len, model_path):
    # Load vocab
    with open(vocab_file) as f:
        vocab = json.load(f)
    vocab_size = len(vocab)

    # Load encoded test dataset
    test_sequences = torch.load(f"{encoded_dir}/test_sequences.pt")
    test_labels = torch.load(f"{encoded_dir}/test_labels.pt")

    test_dataset = OpcodeDataset(test_sequences, test_labels)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    # Load model
    model = OpcodeClassifier(vocab_size, embed_dim=64, hidden_dim=128, num_classes=2)
    model.load_state_dict(torch.load(model_path))
    model.eval()

    # Evaluate
    all_preds, all_labels = [], []
    with torch.no_grad():
        for sequences, labels in test_loader:
            outputs = model(sequences)
            _, predicted = torch.max(outputs, 1)
            all_preds.extend(predicted.tolist())
            all_labels.extend(labels.tolist())

    print("Accuracy:", accuracy_score(all_labels, all_preds))
    print("Precision:", precision_score(all_labels, all_preds, average='weighted'))
    print("Recall:", recall_score(all_labels, all_preds, average='weighted'))
    print("F1 Score:", f1_score(all_labels, all_preds, average='weighted'))

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--encoded", required=True)
    parser.add_argument("--vocab", required=True)
    parser.add_argument("--seq_len", type=int, default=2000)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()

    evaluate(args.encoded, args.vocab, args.seq_len, args.model)