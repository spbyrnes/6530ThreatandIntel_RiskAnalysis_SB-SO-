#!/usr/bin/env python3
import torch, sys, json, os
from model import OpcodeCNN

def load_vocab(path="vocab.json"):
    import json
    with open(path) as f:
        return json.load(f)

def encode_single(path, vocab, seq_len=2000):
    toks = []
    with open(path,'r',errors='ignore') as f:
        for line in f:
            tok = line.strip()
            if not tok:
                continue
            toks.append(tok)
    ids = [vocab.get(t, vocab.get("<UNK>")) for t in toks]
    if len(ids) < seq_len:
        ids = ids + [0]*(seq_len - len(ids))
    else:
        ids = ids[:seq_len]
    return torch.LongTensor([ids])

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test.py path/to/sample.opcode")
        sys.exit(1)
    vocab = load_vocab("vocab.json")
    seq_len = 2000
    model = OpcodeCNN(len(vocab), seq_len=seq_len)
    model.load_state_dict(torch.load("opcode_cnn.pth", map_location="cpu"))
    model.eval()
    sample = encode_single(sys.argv[1], vocab, seq_len)
    out = model(sample)
    print("Log-probs:", out)
    print("Prediction:", out.exp().argmax(dim=1).item())
