#!/usr/bin/env python3
"""
Preprocess .opcode files: normalize lines, remove empty lines and comments.
Usage:
    python preprocess_opcodes.py input_folder output_folder
This copies .opcode files to output_folder with cleaned content.
Each token will be kept one per line (multi-byte tokens are concatenated, e.g. '48 89 e5' -> '4889e5').
"""
import sys, os, argparse

def clean_file(inpath, outpath):
    with open(inpath, 'r', errors='ignore') as fin, open(outpath, 'w') as fout:
        for line in fin:
            s = line.strip()
            if not s:
                continue
            if s.startswith('#'):
                continue
            parts = s.split()
            if len(parts) == 0:
                continue
            token = ''.join(parts)  # normalize multi-byte to one token
            fout.write(token + "\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_folder")
    parser.add_argument("output_folder")
    args = parser.parse_args()
    os.makedirs(args.output_folder, exist_ok=True)
    for fname in os.listdir(args.input_folder):
        if not fname.endswith(".opcode"):
            continue
        src = os.path.join(args.input_folder, fname)
        dst = os.path.join(args.output_folder, fname)
        clean_file(src, dst)
    print("Preprocessing complete. Clean files written to", args.output_folder)

if __name__ == "__main__":
    main()
