import torch
import torch.nn as nn
import torch.nn.functional as F

class OpcodeCNN(nn.Module):
    def __init__(self, vocab_size, seq_len, embed_dim=128, num_classes=2):
        super().__init__()
        self.seq_len = seq_len
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        # Convolutional layers
        self.conv1 = nn.Conv1d(embed_dim, 128, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(128, 256, kernel_size=5, padding=2)
        self.conv3 = nn.Conv1d(256, 512, kernel_size=5, padding=2)

        # Global max pooling
        self.pool = nn.AdaptiveMaxPool1d(1)

        # Fully connected layers
        self.fc1 = nn.Linear(512, 256)
        self.fc2 = nn.Linear(256, num_classes)

        # LogSoftmax for NLLLoss
        self.log_softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        # x: [batch_size, seq_len]
        x = self.embedding(x)          # [batch_size, seq_len, embed_dim]
        x = x.permute(0, 2, 1)        # [batch_size, embed_dim, seq_len] for Conv1d

        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))

        x = self.pool(x).squeeze(-1)  # [batch_size, 512]

        x = F.relu(self.fc1(x))
        x = self.fc2(x)

        x = self.log_softmax(x)       # For NLLLoss
        return x
