#!/usr/bin/env python3
import torch, os, json, argparse, random
from torch.utils.data import TensorDataset, DataLoader, random_split
from model import OpcodeCNN
import torch.optim as optim
import torch.nn as nn
from sklearn.metrics import accuracy_score

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--encoded", default="encoded")
    parser.add_argument("--vocab", default="vocab.json")
    parser.add_argument("--seq_len", type=int, default=2000)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--save", default="opcode_cnn.pth")
    args = parser.parse_args()

    # Reproducibility
    torch.manual_seed(42)
    random.seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    # Load data
    X = torch.load(os.path.join(args.encoded, "X.pt"))
    y = torch.load(os.path.join(args.encoded, "y.pt"))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load vocabulary
    with open(args.vocab) as f:
        vocab = json.load(f)
    vocab_size = len(vocab)

    # Dataset and loaders
    dataset = TensorDataset(X, y)
    n = len(dataset)
    valn = int(0.2 * n)
    trainn = n - valn
    train_ds, val_ds = random_split(dataset, [trainn, valn])

    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch, pin_memory=True)

    # Model, optimizer, loss
    model = OpcodeCNN(vocab_size, seq_len=args.seq_len).to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    criterion = nn.NLLLoss()

    # Training loop
    for epoch in range(1, args.epochs+1):
        model.train()
        losses = []
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            out = model(xb)
            loss = criterion(out, yb)
            loss.backward()
            optimizer.step()
            losses.append(loss.item())

        # Validation
        model.eval()
        ys, preds = [], []
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(device), yb.to(device)
                out = model(xb)
                pred = out.argmax(dim=1).cpu().numpy()
                ys.extend(yb.cpu().numpy())
                preds.extend(pred)
        acc = accuracy_score(ys, preds) if len(ys) > 0 else 0.0
        print(f"Epoch {epoch}: train_loss={sum(losses)/len(losses):.4f} val_acc={acc:.4f}")

    # Save model
    torch.save(model.state_dict(), args.save)
    print("Model saved to", args.save)

if __name__ == "__main__":
    main()
