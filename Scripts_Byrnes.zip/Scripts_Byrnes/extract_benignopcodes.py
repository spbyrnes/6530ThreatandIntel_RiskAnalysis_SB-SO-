from ghidra.util import Msg
import os

# --------- Determine Output Path ---------
exe_path = currentProgram.getExecutablePath()
exe_dir  = os.path.dirname(exe_path)
program_name = os.path.splitext(os.path.basename(exe_path))[0]

output_file_path = os.path.join(exe_dir, "{}.opcode".format(program_name))

# --------- Start Extraction ---------
listing = currentProgram.getListing()
instructions = listing.getInstructions(True)

count = 0

with open(output_file_path, "w") as out_file:

    # Write required header
    out_file.write("Address\tOpcodeBytes\tType\tDescription\n")

    for instr in instructions:

        # extract opcode bytes
        opcode_bytes = instr.getBytes()
        if opcode_bytes is None:
            continue

        opcode_str = " ".join("{:02X}".format(b & 0xFF) for b in opcode_bytes)

        mnemonic = instr.getMnemonicString()

        # Attempt to resolve function name (only for calls)
        func_name = ""
        if mnemonic.lower().startswith("call"):
            try:
                refs = instr.getReferencesFrom()
                for r in refs:
                    target = r.getToAddress()
                    if target:
                        f = getFunctionAt(target)
                        if f:
                            func_name = f.getName()
                            break
            except:
                pass

        # Build final output line
        line = "{}\t{}\t{}".format(instr.getAddress(), opcode_str, mnemonic)
        if func_name:
            line += "\t{}".format(func_name)
        else:
            line += "\t"   # ensure the Description column exists even if empty

        line += "\n"

        out_file.write(line)
        count += 1

# --------- Output Notifications ---------
Msg.info(None, "Benign opcode extraction complete.")
Msg.info(None, "Instructions processed: {}".format(count))
Msg.info(None, "Saved opcodes: {}".format(output_file_path))

print("Extraction complete. Saved to {}".format(output_file_path))
