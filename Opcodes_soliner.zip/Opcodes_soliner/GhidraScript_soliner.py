# Ghidra Python script
# Detects suspicious API calls (imports) and suspicious strings
# Writes actual opcode bytes to a .opcode file in the same folder as the binary
# Fully compatible with Ghidra Jython (Python 2.7)

from ghidra.program.model.symbol import RefType
from ghidra.util import Msg
import os

# Suspicious API calls / keywords
SUSPICIOUS_KEYWORDS = [
    "virtualalloc", "writeprocessmemory", "createremotethread",
    "getprocaddress", "loadlibrary", "ws2_32", "send", "recv",
    "createfile", "shellcode", "decrypt", "unpack", "rwx",
    "inject", "hook", "url", "http", "socket", "regsetvalue",
    "openprocess", "virtualprotect"
]

# Get the path of the binary being analyzed
exe_path = currentProgram.getExecutablePath()
exe_dir = os.path.dirname(exe_path)  # Directory of the binary
program_name = os.path.splitext(os.path.basename(exe_path))[0]  # Filename without extension

# Build output file path
output_file_path = os.path.join(exe_dir, "{}.opcode".format(program_name))

with open(output_file_path, "w") as out_file:
    out_file.write("Address\tOpcodeBytes\tType\tDescription\n")

    listing = currentProgram.getListing()
    
    # -----------------------------
    # Check instructions referencing suspicious imports
    # -----------------------------
    symbol_table = currentProgram.getSymbolTable()
    symbols = symbol_table.getExternalSymbols()
    
    suspicious_imports = []
    for sym in symbols:
        name = sym.getName().lower()
        for keyword in SUSPICIOUS_KEYWORDS:
            if keyword.lower() in name:
                suspicious_imports.append(sym)
                break

    instructions = listing.getInstructions(True)
    for instr in instructions:
        for sym in suspicious_imports:
            refs = instr.getReferencesFrom()
            for ref in refs:
                if ref.getReferenceType().isCall() and ref.getToAddress() == sym.getAddress():
                    # Get opcode bytes
                    bytes_array = instr.getBytes()
                    opcode_bytes = " ".join("{:02X}".format(b & 0xFF) for b in bytes_array)
                    line = "{}\t{}\tCall\t{}\n".format(instr.getAddress(), opcode_bytes, sym.getName())
                    out_file.write(line)
                    Msg.info(None, "Suspicious instruction opcode found: " + line.strip())
                    break

    # -----------------------------
    # Check program strings
    # -----------------------------
    data_iter = listing.getDefinedData(True)
    for data in data_iter:
        if data.getDataType().getName() == "string":
            string_val = str(data.getValue()).lower()
            for keyword in SUSPICIOUS_KEYWORDS:
                if keyword.lower() in string_val:
                    address = data.getAddress()
                    # No instruction bytes for pure string, leave empty
                    line = "{}\t\tString\t{}\n".format(address, string_val)
                    out_file.write(line)
                    Msg.info(None, "Suspicious string found: " + line.strip())
                    break

print("Scan complete. Results written to {}".format(output_file_path))
