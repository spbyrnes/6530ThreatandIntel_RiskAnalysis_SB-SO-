#!/bin/bash
set -e
python3 preprocess_opcodes.py data/benign data/benign_clean
python3 preprocess_opcodes.py data/malware data/malware_clean
python3 build_vocab.py data/benign_clean data/malware_clean
python3 encode_dataset.py --benign data/benign_clean --malware data/malware_clean --seq_len 2000 --outdir encoded
python3 train.py --encoded encoded --vocab vocab.json --seq_len 2000 --epochs 10
